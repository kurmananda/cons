// src/app/payment-success/page.jsx

'use client';

import { useEffect, useState } from 'react';

import {
  Loader2,
  CheckCircle2,
  XCircle
} from 'lucide-react';

export default function PaymentSuccessPage() {

  const [loading, setLoading] =
    useState(true);

  const [success, setSuccess] =
    useState(false);

  const [message, setMessage] =
    useState('Verifying payment...');

  useEffect(() => {

    const verifyPayment =
      async () => {

        try {

          const params =
            new URLSearchParams(
              window.location.search
            );

          const order_id =
            params.get('order_id');

          if (!order_id) {

            setMessage(
              'Order ID missing'
            );

            setLoading(false);

            return;
          }

          // =========================
          // VERIFY PAYMENT
          // =========================

          const verifyResponse =
            await fetch(
              `/api/verify-payment?order_id=${order_id}`
            );

          const verifyData =
            await verifyResponse.json();

          console.log(
            'VERIFY DATA:',
            verifyData
          );

          const paymentSuccess =

            verifyData?.payment_status ===
              'SUCCESS' ||

            verifyData?.order_status ===
              'PAID' ||

            verifyData?.order_status ===
              'SUCCESS';

          if (!paymentSuccess) {

            setSuccess(false);

            setMessage(
              'Payment not completed'
            );

            setLoading(false);

            return;
          }

          // =========================
          // GET LOCAL DATA
          // =========================

          const email =
            localStorage.getItem(
              'registration_email'
            ) || '';

          const workshop_ids =
            JSON.parse(
              localStorage.getItem(
                'selected_workshops'
              ) || '[]'
            );

          const details =
            JSON.parse(
              localStorage.getItem(
                'registration_details'
              ) || '{}'
            );

          console.log({
            email,
            workshop_ids,
            details
          });

          if (!email) {

            throw new Error(
              'Registration data missing'
            );
          }

          setMessage(
            'Saving registration...'
          );

          // =========================
          // SAVE REGISTRATION
          // =========================

          const saveResponse =
            await fetch(
              '/api/save-registration',
              {

                method: 'POST',

                headers: {
                  'Content-Type':
                    'application/json'
                },

                body: JSON.stringify({

                  email,

                  workshop_ids,

                  details,

                  payment_id:
                    verifyData.cf_payment_id,

                  order_id,

                  amount:
                    verifyData.order_amount
                })
              }
            );

          const saveData =
            await saveResponse.json();

          console.log(
            'SAVE DATA:',
            saveData
          );

          if (!saveResponse.ok) {

            throw new Error(
              saveData.message ||
              'Failed to save registration'
            );
          }

          // =========================
          // SAVE DASHBOARD SESSION
          // =========================

          localStorage.setItem(
            'last_active_email',
            email
          );

          // cleanup temp storage

          localStorage.removeItem(
            'selected_workshops'
          );

          localStorage.removeItem(
            'registration_details'
          );

          setSuccess(true);

          setMessage(
            'Payment successful'
          );

          // =========================
          // REDIRECT HOME
          // =========================

          setTimeout(() => {

            window.location.href =
              '/';

          }, 2000);

        } catch (err) {

          console.log(err);

          setSuccess(false);

          setMessage(
            err.message ||
            'Something went wrong'
          );

        } finally {

          setLoading(false);
        }
      };

    verifyPayment();

  }, []);

  return (

    <div className="min-h-screen bg-[#0a0a0a] text-white flex flex-col items-center justify-center px-6">

      <div className="bg-neutral-900 border border-white/10 rounded-[2rem] p-10 flex flex-col items-center max-w-md w-full">

        {loading ? (

          <Loader2
            className="animate-spin text-[#3b82f6]"
            size={60}
          />

        ) : success ? (

          <CheckCircle2
            className="text-green-500"
            size={70}
          />

        ) : (

          <XCircle
            className="text-red-500"
            size={70}
          />
        )}

        <h1 className="mt-6 text-3xl font-black uppercase italic tracking-tighter text-center">

          {loading
            ? 'Processing'
            : success
            ? 'Success'
            : 'Failed'}

        </h1>

        <p className="mt-4 text-neutral-400 text-center text-sm leading-relaxed">

          {message}

        </p>

      </div>

    </div>
  );
}