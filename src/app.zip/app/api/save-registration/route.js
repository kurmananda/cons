import { NextResponse } from 'next/server';

import { createClient }
from '@supabase/supabase-js';

const supabase = createClient(
  'https://aeytetacgdmxtsotjfti.supabase.co',
  'sb_publishable_waq7AxdRDLcOndA5NF5vKg_HSr9IAn8'
);

export async function POST(req) {

  try {

    const body = await req.json();

    console.log('SAVE BODY:', body);

    const email =
      body.email || '';

    const newWorkshopIds =
      body.workshop_ids || '';

    const details =
      body.details || {};

    const payment_id =
      body.payment_id || '';

    const order_id =
      body.order_id || '';

    const amount =
      Number(body.amount || 0);

    if (!email) {

      return NextResponse.json(
        {
          success: false,
          message: 'Email missing'
        },
        { status: 400 }
      );
    }

    // =====================================
    // FETCH EXISTING USER
    // =====================================

    const { data: existingUser } =
      await supabase
        .from('registrations')
        .select('*')
        .eq(
          'email',
          email.toLowerCase()
        )
        .maybeSingle();

    // =====================================
    // EXISTING ARRAYS
    // =====================================

    const existingWorkshopIds =
      existingUser?.workshop_ids || [];

    const existingPaymentIds =
      existingUser?.payment_ids || [];

    const existingOrderIds =
      existingUser?.order_ids || [];

    const existingStatuses =
      existingUser?.payment_statuses || [];

    const existingAmounts =
      existingUser?.amounts || [];

    // =====================================
    // INCOMING WORKSHOPS
    // =====================================

    const incomingIds =
      String(newWorkshopIds)
        .split(',')
        .map(id => id.trim())
        .filter(Boolean);

    // =====================================
    // MERGE WORKSHOPS
    // =====================================

    const finalWorkshopIds = [
      ...new Set([
        ...existingWorkshopIds,
        ...incomingIds
      ])
    ];

    // =====================================
    // APPEND HISTORIES
    // =====================================

    const finalPaymentIds = [
      ...existingPaymentIds,
      payment_id
    ];

    const finalOrderIds = [
      ...existingOrderIds,
      order_id
    ];

    const finalStatuses = [
      ...existingStatuses,
      'paid'
    ];

    const finalAmounts = [
      ...existingAmounts,
      amount
    ];

    // =====================================
    // TOTAL AMOUNT
    // =====================================

    const totalAmount =
      finalAmounts.reduce(
        (sum, val) => sum + Number(val),
        0
      );

    // =====================================
    // UPSERT
    // =====================================

    const { data, error } =
      await supabase
        .from('registrations')
        .upsert(
          [
            {
              email:
                email.toLowerCase(),

              workshop_ids:
                finalWorkshopIds,

              payment_ids:
                finalPaymentIds,

              order_ids:
                finalOrderIds,

              payment_statuses:
                finalStatuses,

              amounts:
                finalAmounts,

              total_amount:
                totalAmount,

              details,

              status: 'confirmed',

              updated_at:
                new Date().toISOString()
            }
          ],
          {
            onConflict: 'email'
          }
        )
        .select();

    if (error) {

      console.log(error);

      return NextResponse.json(
        {
          success: false,
          message: error.message
        },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data
    });

  } catch (err) {

    console.log(err);

    return NextResponse.json(
      {
        success: false,
        message: err.message
      },
      { status: 500 }
    );
  }
}