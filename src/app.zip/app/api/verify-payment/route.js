// src/app/api/verify-payment/route.js

import { NextResponse } from 'next/server';

export async function GET(req) {

  try {

    const { searchParams } =
      new URL(req.url);

    const order_id =
      searchParams.get('order_id');

    if (!order_id) {

      return NextResponse.json(
        {
          success: false,
          message: 'Order ID missing'
        },
        { status: 400 }
      );
    }

    const response = await fetch(

      `https://sandbox.cashfree.com/pg/orders/${order_id}/payments`,

      {

        headers: {

          'x-client-id':
            'TEST1105651582cfb10e91fe60700a9251565011',

          'x-client-secret':
            'cfsk_ma_test_06d40c64041ccdcb81008ad536f5586a_3e340568',

          'x-api-version':
            '2023-08-01'
        }
      }
    );

    const data =
      await response.json();

    console.log(data);

    if (!response.ok) {

      return NextResponse.json(
        {
          success: false,
          message:
            data.message ||
            'Verification failed'
        },
        { status: 500 }
      );
    }

    // GET SUCCESS PAYMENT

    const successPayment =
      data.find(
        p =>
          p.payment_status ===
          'SUCCESS'
      );

    return NextResponse.json({

      success: true,

      payment_status:
        successPayment
          ?.payment_status || 'FAILED',

      cf_payment_id:
        successPayment
          ?.cf_payment_id || '',

      order_amount:
        successPayment
          ?.payment_amount || 0
    });

  } catch (err) {

    console.log(err);

    return NextResponse.json(
      {
        success: false,
        message: err.message
      },
      { status: 500 }
    );
  }
}