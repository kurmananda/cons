
'use client';

import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Check,
  ArrowRight,
  Rocket,
  Cpu,
  Satellite,
  Brain,
  Info,
  Loader2,
  Sparkles,
  ShoppingCart,
  Lock,
  ChevronRight,
} from 'lucide-react';

import { createClient } from '@supabase/supabase-js';

// --- INITIALIZE SUPABASE ---
const supabase = createClient(
  'https://aeytetacgdmxtsotjfti.supabase.co',
  'sb_publishable_waq7AxdRDLcOndA5NF5vKg_HSr9IAn8'
);

export default function WorkshopRegistration() {

  // --- STATE MANAGEMENT ---
  const [loading, setLoading] = useState(true);
  const [isChecking, setIsChecking] = useState(false);

  const [step, setStep] = useState(1);

  const [selectedItems, setSelectedItems] = useState([]);
  const [registeredItems, setRegisteredItems] = useState([]);

  const [comboApplied, setComboApplied] = useState(false);

  const [formData, setFormData] = useState({
    email: '',
    name: '',
    class: '',
    schoolId: '',
    college: '',
    city: '',
    phone: '',
  });

  // --- WORKSHOP DATA ---
  const workshops = [
    {
      id: '1',
      name: 'Satellite Building',
      price: 349,
      desc: 'Advanced orbital mechanics and nano-satellite design.',
      icon: <Satellite size={20} />,
    },
    {
      id: '2',
      name: 'Launch Vehicle Workshop',
      price: 349,
      desc: 'Aerodynamics and propulsion system implementation.',
      icon: <Rocket size={20} />,
    },
    {
      id: '3',
      name: 'Agentic AI',
      price: 299,
      desc: 'Autonomous reasoning for deep space robotics.',
      icon: <Cpu size={20} />,
    },
    {
      id: '4',
      name: 'Python Workshop',
      price: 299,
      desc: 'Predictive modeling for celestial navigation.',
      icon: <Brain size={20} />,
    },
  ];

  const merchItem = {
    id: '5',
    name: 'Space Merch',
    price: 599,
    desc: 'Official Conscientia 2026 exclusive merchandise.',
  };

  const combos = [
    { id: 'c1', name: 'Combo', ids: ['1', '2'], price: 649 },
    { id: 'c2', name: 'AI Combo', ids: ['3', '4'], price: 549 },
    { id: 'c3', name: 'Mega Combo', ids: ['1', '2', '3', '4'], price: 1149 },
    { id: 'c4', name: 'Ultimate Combo', ids: ['1', '2', '3', '4', '5'], price: 1699 },
  ];

  // --- VALIDATIONS ---
  const isPhoneValid =
    formData.phone.replace(/\D/g, '').length >= 10;

  const isEmailValid =
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email);

  const isStep2Valid =
    Object.values(formData).every(
      (val) => val.trim() !== ''
    );

  // --- COMBO LOGIC ---
  const qualifyingCombo = useMemo(() => {
    const sortedCombos = [...combos].sort(
      (a, b) => b.ids.length - a.ids.length
    );

    return sortedCombos.find((c) =>
      c.ids.every((id) =>
        [...selectedItems, ...registeredItems].includes(id)
      )
    );
  }, [selectedItems, registeredItems]);

  const activeCombo = comboApplied
    ? qualifyingCombo
    : null;

  const totalAmount = useMemo(() => {

    const allPossibleItems = [
      ...workshops,
      merchItem,
    ];

    const itemsToPayFor = selectedItems.filter(
      (id) => !registeredItems.includes(id)
    );

    if (activeCombo) {

      const nonComboItems = allPossibleItems.filter(
        (w) =>
          itemsToPayFor.includes(w.id) &&
          !activeCombo.ids.includes(w.id)
      );

      const extraPrice = nonComboItems.reduce(
        (acc, curr) => acc + curr.price,
        0
      );

      return activeCombo.price + extraPrice;
    }

    return allPossibleItems
      .filter((w) => itemsToPayFor.includes(w.id))
      .reduce((acc, curr) => acc + curr.price, 0);

  }, [selectedItems, registeredItems, activeCombo]);

  // --- SELECTION HANDLERS ---
  const toggleSelection = (id) => {

    if (registeredItems.includes(id)) return;

    setSelectedItems((prev) => {

      const isSelected = prev.includes(id);

      const newItems = isSelected
        ? prev.filter((i) => i !== id)
        : [...prev, id];

      if (
        isSelected &&
        activeCombo?.ids.includes(id)
      ) {
        setComboApplied(false);
      }

      return newItems;
    });
  };

  const selectCombo = (ids) => {

    const freshIds = ids.filter(
      (id) => !registeredItems.includes(id)
    );

    setSelectedItems((prev) =>
      Array.from(new Set([...prev, ...freshIds]))
    );

    setComboApplied(true);
  };

  // --- PERSISTENCE ---
  useEffect(() => {
    setLoading(false);
  }, []);

  // --- EMAIL CHECK ---
  const handleEmailCheck = async () => {
    if (!isEmailValid) return;

    setIsChecking(true);

    try {
      const { data, error } = await supabase
        .from('registrations')
        .select('*')
        .eq('email', formData.email.toLowerCase().trim())
        .maybeSingle();

      if (error) {
        console.log(error);
      }

      // =====================================
      // EXISTING USER
      // =====================================

      if (data && data.payment_status === 'paid') {

        setRegisteredItems(
          Array.isArray(data.workshop_ids)
            ? data.workshop_ids
            : []
        );

        if (data.details) {
          setFormData(data.details);
        }

        setStep(4);

      } else {

        // =====================================
        // NEW USER
        // =====================================

        setStep(2);
      }

    } catch (err) {

      console.log(err);

      setStep(2);

    } finally {

      setIsChecking(false);
    }
  };

  // =========================================================
  // ================= PAYMENT FUNCTION FIX ==================
  // =========================================================

  const handlePayment = async () => {

    if (selectedItems.length === 0)
      return;

    setIsChecking(true);

    try {

      // =========================
      // SAVE EVERYTHING FIRST
      // =========================

      localStorage.setItem(
        'registration_email',
        formData.email
          .toLowerCase()
          .trim()
      );

      localStorage.setItem(
        'selected_workshops',
        JSON.stringify(selectedItems)
      );

      localStorage.setItem(
        'registration_details',
        JSON.stringify(formData)
      );

      // =========================
      // CREATE ORDER
      // =========================

      const response = await fetch(
        '/api/cashfree',
        {
          method: 'POST',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({

            customer_id:
              formData.email.replace(
                /[@.]/g,
                '_'
              ),

            customer_phone:
              formData.phone
                .replace(/\D/g, '')
                .slice(-10),

            customer_email:
              formData.email
                .toLowerCase()
                .trim(),

            customer_name:
              formData.name,

            order_amount:
              totalAmount,

            metadata: {

              workshop_ids:
                selectedItems.join(','),

              college:
                formData.college,

              is_new_registration:
                registeredItems.length === 0
                  ? 'true'
                  : 'false'
            }
          })
        }
      );

      const orderData =
        await response.json();

      if (!response.ok) {

        throw new Error(
          orderData.message ||
          'Order creation failed'
        );
      }

      // =========================
      // CASHFREE POPUP
      // =========================

      const { load } =
        await import(
          '@cashfreepayments/cashfree-js'
        );

      const cashfree =
        await load({
          mode: 'sandbox'
        });

      cashfree.checkout({

        paymentSessionId:
          orderData.payment_session_id,

        // THIS MAKES IT POPUP
        redirectTarget: '_modal'
      });

    } catch (err) {

      console.log(err);

      alert(
        `Payment Error: ${err.message}`
      );

    } finally {

      setIsChecking(false);
    }
  };
  // =========================================================

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a]" />
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans selection:bg-[#3b82f6]/30 flex flex-col items-center">

      <nav className="pb-5 border-b border-white/5 flex w-full items-center justify-center bg-black/50 backdrop-blur-md sticky top-0 z-50">
        <div className="flex gap-3 pt-5">
          {[1, 2, 3].map((i) => (
            <motion.div
              key={i}
              animate={{
                width: step === i ? 40 : 12,
                backgroundColor:
                  step >= i
                    ? '#3b82f6'
                    : '#262626',
              }}
              className="h-1.5 rounded-full"
            />
          ))}
        </div>
      </nav>

      <main className="max-w-5xl w-full mx-auto p-6 pt-12 pb-40">
        {step < 4 && (
          <div className="mb-8 flex items-center gap-3 p-4 bg-[#3b82f6]/10 border border-[#3b82f6]/20 rounded-2xl">
            <Info className="text-[#3b82f6] shrink-0" size={20} />
            <p className="text-[11px] font-bold uppercase tracking-wider text-[#3b82f6]/80 leading-relaxed">
              Note: Confirmation and meeting links will be sent exclusively to your registered email address.
            </p>
          </div>
        )}

        <AnimatePresence mode="wait">
          {/* STEP 1: EMAIL */}
          {step === 1 && (
            <motion.div key="s1" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="max-w-md mx-auto space-y-8 mt-12">
              <div className="text-center space-y-2">
                <h1 className="text-4xl font-black uppercase tracking-tighter italic">Workshop Registration<span className="text-[#3b82f6]">.</span></h1>
                <p className="text-neutral-500 text-sm font-bold tracking-widest uppercase">Enter email to proceed</p>
              </div>
              <div className="space-y-4">
                <input
                  type="email" placeholder="student@university.edu" value={formData.email}
                  className="w-full bg-neutral-900 border border-neutral-800 p-5 rounded-2xl focus:border-[#3b82f6] outline-none text-white transition-all"
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
                <button
                  onClick={handleEmailCheck} disabled={!isEmailValid || isChecking}
                  className="w-full bg-[#3b82f6] text-black p-5 rounded-2xl font-black uppercase tracking-widest text-sm hover:bg-white transition-all flex items-center justify-center gap-2 group disabled:opacity-50"
                >
                  {isChecking ? <Loader2 className="animate-spin" size={18} /> : "Verify Credentials"}
                  {!isChecking && <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />}
                </button>
              </div>
            </motion.div>
          )}

          {/* STEP 2: PROFILE DETAILS */}
          {step === 2 && (
            <motion.div key="s2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-10">
              <div className="text-center">
                <h1 className="text-4xl font-black uppercase italic tracking-tighter">Details Required<span className="text-[#3b82f6] text-6xl leading-none">.</span></h1>
                <p className="text-neutral-500 text-sm font-black uppercase tracking-[0.2em] mt-2">All fields are mandatory for certification</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {['name', 'class', 'schoolId', 'college', 'city', 'phone'].map(field => {
                  const displayLabels = { college: 'School / College', schoolId: 'ID Number / Roll No', name: 'Full Name', class: 'Grade / Year', phone: 'WhatsApp Number' };
                  return (
                    <div key={field} className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-[0.3em] text-[#3b82f6] ml-2 flex items-center gap-2">
                        {displayLabels[field] || field}
                      </label>
                      <input
                        placeholder={field === 'phone' ? '91XXXXXXXXXX' : `Enter ${displayLabels[field] || field}`}
                        value={formData[field]}
                        className="w-full bg-neutral-900 border border-neutral-800 p-4 rounded-xl focus:border-[#3b82f6] outline-none text-white transition-all"
                        onChange={(e) => setFormData({ ...formData, [field]: e.target.value })}
                      />
                    </div>
                  );
                })}
              </div>
              <button
                onClick={() => isPhoneValid ? setStep(3) : alert("Valid WhatsApp number required")}
                disabled={!isStep2Valid}
                className="w-full bg-white text-black p-5 rounded-2xl font-black uppercase tracking-widest text-sm hover:bg-[#3b82f6] transition-all disabled:opacity-30"
              >
                Proceed to Selection
              </button>
            </motion.div>
          )}

          {/* STEP 3: WORKSHOP SELECTION */}
          {step === 3 && (
            <motion.div key="s3" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-20">
              {/* MERCH SECTION */}
              <section>
                <h2 className="text-3xl font-black italic uppercase tracking-tighter mb-6">Space Merch<span className="text-[#3b82f6]">.</span></h2>
                <div className={`relative overflow-hidden rounded-[2.5rem] border-2 transition-all duration-500 ${registeredItems.includes('5') ? 'border-green-500/50 bg-green-500/5 shadow-none' : selectedItems.includes('5') ? 'border-[#3b82f6] bg-[#3b82f6]/5 shadow-[0_0_50px_rgba(59,130,246,0.1)]' : 'border-white/5 bg-neutral-900/40'}`}>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 p-8 md:p-12">
                    <div className="flex gap-4 h-64 md:h-80">
                      <div className="flex-1 relative rounded-2xl overflow-hidden bg-black/40 border border-white/5 flex items-center justify-center text-[10px] font-black text-white/10 uppercase tracking-widest">Front View</div>
                      <div className="flex-1 relative rounded-2xl overflow-hidden bg-black/40 border border-white/5 flex items-center justify-center text-[10px] font-black text-white/10 uppercase tracking-widest">Back View</div>
                    </div>
                    <div className="flex flex-col justify-center space-y-6">
                      <div>
                        <h3 className="text-2xl font-black uppercase italic tracking-tighter mb-2">{merchItem.name}</h3>
                        <p className="text-neutral-400 text-sm leading-relaxed">{merchItem.desc}</p>
                      </div>
                      <div className="flex items-center gap-6">
                        <div className="text-3xl font-black text-[#3b82f6]">₹{merchItem.price}</div>
                        <button
                          onClick={() => toggleSelection('5')}
                          disabled={registeredItems.includes('5')}
                          className={`flex-1 py-4 rounded-2xl font-black uppercase tracking-widest text-xs transition-all flex items-center justify-center gap-3 ${registeredItems.includes('5') ? 'bg-green-500/20 text-green-500' : selectedItems.includes('5') ? 'bg-[#3b82f6] text-black' : 'bg-white text-black hover:bg-[#3b82f6]'}`}
                        >
                          {registeredItems.includes('5') ? <Lock size={18} /> : selectedItems.includes('5') ? <Check size={18} /> : <ShoppingCart size={18} />}
                          {registeredItems.includes('5') ? 'Purchased' : selectedItems.includes('5') ? 'Remove' : 'Add to Kit'}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              {/* COMBOS */}
              <section>
                <h2 className="text-2xl font-black italic uppercase tracking-tighter mb-8">Bundles<span className="text-[#3b82f6]">.</span></h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {combos.map(combo => {
                    const alreadyOwnsAll = combo.ids.every(id => registeredItems.includes(id));
                    return (
                      <div key={combo.id} className="p-6 rounded-[2rem] bg-neutral-900 border border-white/5 flex flex-col justify-between hover:border-[#3b82f6]/40 transition-colors">
                        <h4 className="font-black italic uppercase tracking-tighter text-lg">{combo.name}</h4>
                        <div className="mt-6">
                          <div className="text-[#3b82f6] font-black text-xl mb-3">₹{combo.price}</div>
                          <button
                            disabled={alreadyOwnsAll}
                            onClick={() => selectCombo(combo.ids)}
                            className="w-full py-2.5 bg-neutral-800 disabled:opacity-20 hover:bg-[#3b82f6] hover:text-black rounded-xl text-[9px] font-black uppercase tracking-widest transition-all"
                          >
                            {alreadyOwnsAll ? 'Owned' : 'Apply Combo'}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>

              {/* INDIVIDUAL */}
              <section>
                <h2 className="text-2xl font-black italic uppercase tracking-tighter mb-8">Workshops<span className="text-[#3b82f6]">.</span></h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {workshops.map(ws => {
                    const isRegistered = registeredItems.includes(ws.id);
                    return (
                      <div
                        key={ws.id} onClick={() => toggleSelection(ws.id)}
                        className={`cursor-pointer p-6 rounded-[2rem] border-2 transition-all ${isRegistered ? 'border-green-500/20 bg-green-500/5' : selectedItems.includes(ws.id) ? 'border-[#3b82f6] bg-[#3b82f6]/5' : 'border-white/5 bg-neutral-900/40'}`}
                      >
                        <div className="flex justify-between items-start mb-6">
                          <div className={`p-3 rounded-xl ${isRegistered ? 'bg-green-500/20 text-green-500' : selectedItems.includes(ws.id) ? 'bg-[#3b82f6] text-black' : 'bg-neutral-800'}`}>{ws.icon}</div>
                          {isRegistered ? <Lock size={18} className="text-green-500" /> : selectedItems.includes(ws.id) && <Check size={18} className="text-[#3b82f6]" />}
                        </div>
                        <h3 className="font-black italic uppercase tracking-tighter text-lg mb-1">{ws.name}</h3>
                        <div className="text-xs font-black text-neutral-500 uppercase">{isRegistered ? 'Enrolled' : `₹${ws.price}`}</div>
                      </div>
                    );
                  })}
                </div>
              </section>
            </motion.div>
          )}

          {/* STEP 4: REGISTRATION DASHBOARD */}
          {step === 4 && (
            <motion.div key="s4" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="mt-12 space-y-12 w-full max-w-2xl mx-auto">
              <div className="text-center space-y-4">
                <div className="w-20 h-20 bg-green-500 text-black rounded-full flex items-center justify-center mx-auto shadow-[0_0_50px_rgba(34,197,94,0.3)]">
                  <Check size={40} strokeWidth={3} />
                </div>
                <h1 className="text-5xl font-black uppercase italic tracking-tighter leading-tight">Registration Active<span className="text-green-500">.</span></h1>
                <div className="flex flex-wrap justify-center gap-2">
                  <span className="px-3 py-1 bg-neutral-900 rounded-full text-[10px] font-black uppercase tracking-widest text-neutral-400 border border-white/5">{formData.email}</span>
                </div>
              </div>

              <div className="bg-neutral-900/50 backdrop-blur-xl border border-white/5 rounded-[2.5rem] p-8 space-y-6">
                <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-[#3b82f6]">Your Dashboard</h3>
                <div className="space-y-3">
                  {[...workshops, merchItem].filter(item => registeredItems.includes(item.id)).map(item => (
                    <div key={item.id} className="flex justify-between items-center p-5 bg-black/40 rounded-2xl border border-white/5 group hover:border-green-500/30 transition-all">
                      <div className="flex items-center gap-4">
                        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                        <span className="font-black uppercase italic tracking-tighter text-lg">{item.name}</span>
                      </div>
                      <span className="text-[10px] bg-green-500/10 text-green-500 px-4 py-1.5 rounded-full font-black uppercase tracking-widest border border-green-500/20">Active</span>
                    </div>
                  ))}
                  {registeredItems.length === 0 && <p className="text-neutral-600 italic text-center py-4 uppercase text-[10px] tracking-widest">No Active Modules Found</p>}
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button onClick={() => setStep(3)} className="px-10 py-5 bg-[#3b82f6] text-black rounded-3xl font-black uppercase tracking-widest text-[10px] hover:bg-white transition-all">Buy More Modules</button>
                <button
                  onClick={() => {
                    setRegisteredItems([]);
                    setSelectedItems([]);
                    setFormData({
                      email: '',
                      name: '',
                      class: '',
                      schoolId: '',
                      college: '',
                      city: '',
                      phone: ''
                    });

                    setStep(1);
                  }}
                  className="px-10 py-5 bg-neutral-900 text-white border border-white/5 rounded-3xl font-black uppercase tracking-widest text-[10px] hover:bg-red-500 hover:border-red-500 transition-all"
                >
                  Logout / Switch Account
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* --- FLOATING CHECKOUT --- */}
      <AnimatePresence>
        {step === 3 && selectedItems.filter(id => !registeredItems.includes(id)).length > 0 && (
          <motion.div initial={{ y: 100 }} animate={{ y: 0 }} exit={{ y: 100 }} className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[90%] max-w-4xl bg-black/80 backdrop-blur-2xl border border-white/10 p-6 rounded-[2.5rem] flex justify-between items-center z-[70] shadow-2xl">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[10px] font-black text-neutral-500 uppercase tracking-widest">Total Payable</span>
                {activeCombo && <span className="bg-[#3b82f6]/20 text-[#3b82f6] text-[8px] font-black uppercase px-2 py-0.5 rounded border border-[#3b82f6]/20">{activeCombo.name}</span>}
              </div>
              <p className="text-4xl font-black italic tracking-tighter">₹{totalAmount}</p>
              {!activeCombo && qualifyingCombo && (
                <button onClick={() => setComboApplied(true)} className="mt-1 flex items-center gap-1.5 text-[#3b82f6] text-[9px] font-black uppercase tracking-tighter group">
                  <Sparkles size={10} className="group-hover:rotate-12 transition-transform" /> Optimize for {qualifyingCombo.name}?
                </button>
              )}
            </div>
            <button
              disabled={isChecking}
              onClick={handlePayment}
              className="bg-[#3b82f6] text-black px-12 py-5 rounded-3xl font-black uppercase tracking-widest text-sm hover:bg-white transition-all flex items-center gap-3 disabled:opacity-50"
            >
              {isChecking ? <Loader2 className="animate-spin" size={18} /> : <>Checkout <ChevronRight size={18} /></>}
            </button>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}